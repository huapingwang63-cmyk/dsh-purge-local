# dsh-lang-zh · DSH 简体中文语言插件

> Make DeepSeek Harness agents **always reply in Simplified Chinese**, including
> the short narration text between tool calls. 让 DSH 的模型始终用简体中文回复，
> 连工具调用之间的"边干活边说"的叙述文字也是中文。

## 作用 / What it does

DSH 本身不会固定模型的输出语言——模型会跟随你的语言写最终答案，但中间过程的
叙述文字（轨迹里的 assistant 短句）容易受上下文影响漂移到英文。本插件在系统提示词里
注入一条明确的语言指令，让**所有会话、所有 agent preset** 都：

- 用简体中文写最终回复；
- 工具调用之间的叙述文字也用简体中文；
- 思考过程尽量使用中文；
- 除非用户明确要求使用其他语言。

安装后**立即生效（无需重启）**，对之后产生的每条消息都有效。

## 为什么需要 / Why

两次对话、同样的模型（deepseek-v4-flash）、同样的系统提示词，一次叙述是中文、
一次是英文——这不是 bug，是模型每轮自主选择输出语言的结果。上下文里英文内容
（工具输出、日志）越多，叙述越容易漂成英文。与其每次开头叮嘱一句，不如用插件
一次性固定下来。

## 安装 / Install

```sh
dsh plugin --profile web add dsh-lang-zh
```

重启 `dsh web`（或等下一次重启）后，插件作为 bundle 层加载，立即生效。

> 与直接在 profile 的 `cordis.patch.yml` 里改 persona 相比，本插件**不覆盖** web-app
> 自带的 persona，也不会被某个 preset 的 persona 遮蔽，因此对每个 preset 的每个会话都稳定生效。

## 工作原理 / How it works

1. `cordis.patch.yml` 作为 bundle 补丁，向 profile 层栈插入一行
   `- id: lang-zh / name: dsh-lang-zh`（与 `dshmarket` 等插件相同的标准方式）。
2. Loader 从 profile 的 `node_modules` 导入本包，插件通过
   `ctx.systemPrompt.section()` 注册一个独立命名的 `user:language` section。
3. 每次组装系统提示词时，该 section 都会出现在 persona 之后，对所有会话生效。

## 配置 / Configuration

在 profile 补丁层可覆盖默认指令文本与顺序（可选）：

```yaml
- id: lang-zh
  config:
    text: 始终使用简体中文回复（包括工具调用之间的叙述文字），除非用户明确要求使用其他语言。思考过程也请尽量使用中文。
    order: 1
```

| 字段 | 默认 | 说明 |
|---|---|---|
| `text` | 见上方默认文案 | 注入系统提示词的指令文本 |
| `order` | `1` | section 顺序（deployment persona 在 0，默认紧跟其后） |

## 卸载 / Uninstall

```sh
dsh plugin --profile web remove dsh-lang-zh
```

## 许可 / License

MIT
