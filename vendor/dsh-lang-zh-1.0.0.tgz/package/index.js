/**
 * dsh-lang-zh — keep DeepSeek Harness agents replying in Simplified Chinese.
 *
 * Registers an independent `user:language` system-prompt section so that every
 * session of every agent preset carries the instruction. Unlike overriding the
 * deployment persona, this does not clobber the persona shipped by a bundle and
 * is never shadowed by a preset persona (presets shadow the `deployment:persona`
 * section by name only), so the language rule survives in all sessions.
 */

/** Stable Cordis plugin name. */
export const name = 'lang-zh'

/** Services required before the section can be registered. */
export const inject = ['systemPrompt']

/** Default instruction text injected into the system prompt. */
export const DEFAULT_TEXT =
  '始终使用简体中文回复（包括工具调用之间的叙述文字），除非用户明确要求使用其他语言。思考过程也请尽量使用中文。'

/**
 * Plugin body: register the language section for the mounting context's scope.
 * @param ctx - plugin context carrying the `systemPrompt` service.
 * @param config - `text` (instruction wording) and `order` (section order; the
 * deployment persona sits at 0, so the default 1 renders right after it).
 */
export function apply(ctx, config = {}) {
  const text = config.text ?? DEFAULT_TEXT
  const order = config.order ?? 1
  ctx.effect(() => ctx.systemPrompt.section({
    name: 'user:language',
    order,
    text,
  }), 'lang-zh: language section')
}
